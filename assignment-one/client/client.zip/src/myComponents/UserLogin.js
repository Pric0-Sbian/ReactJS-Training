import React from 'react';
import '../App.css';
import LoginForm from './LoginForm';
export default function UserLogin({user}) {

    return (
        <>
            <LoginForm />
        </>
    )
}
