import React from 'react';
import '../App.css';

export default function Footer() {
    return (
        <div>
            <footer ><p><i>Footer</i></p></footer>
        </div>
    )
}
