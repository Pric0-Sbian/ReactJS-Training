import React from 'react'

export default function DeleteUser() {
    return (
        <div>
            
        </div>
    )
}
